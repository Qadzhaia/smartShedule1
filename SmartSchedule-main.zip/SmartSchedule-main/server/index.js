import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import passport from 'passport';
import keys from './config/keys.js';
import passportMiddleware from './middleware/passport.js';
import AuthRegister from './routes/auth.js';
import UserRoute from './routes/user.js';
import GroupRouter from './routes/group.js';
import StudentRouter from './routes/student.js';
import LessonRouter from './routes/lesson.js';
import OneTimeRouter from './routes/oneTime.js';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import morgan from 'morgan';
import Fingerprint from 'express-fingerprint';
import cookieParser from 'cookie-parser';
import errorMiddleware from './middleware/error-middleware.js';


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(cors({
    credentials: true,
    origin: true
}));

app.use(express.urlencoded({extended:true}))
app.use(morgan("dev"))
app.use(Fingerprint())
app.use(passport.initialize())
passportMiddleware(passport);


app.use('/api/auth', AuthRegister);
app.use('/api/user', UserRoute);
app.use('/api/group', GroupRouter);
app.use('/api/student', StudentRouter);
app.use('/api/lesson', LessonRouter);
app.use('/api/onetime', OneTimeRouter);

app.use(errorMiddleware)

const CONNECTION_URL = keys.mongo_uri;
const PORT = process.env.PORT || 5000;

const start = async () => {
	try {
		await mongoose.connect(CONNECTION_URL, {
			useCreateIndex: true,
			useNewUrlParser: true,
			useUnifiedTopology: true,
			useFindAndModify: false
		})

		app.listen(PORT, () => console.log(`Server running at port: ${PORT}`))
		
	} catch (error) {
		console.log(error.message)
	}
}

start();

if(process.env.PRODUCTION === "true"){
	app.use('/', express.static(path.join(__dirname, '../client', 'build')));

	app.get('*', (req,res)=>{
		res.sendFile(path.resolve(__dirname,'../client', 'build', 'index.html'));
	})
}
