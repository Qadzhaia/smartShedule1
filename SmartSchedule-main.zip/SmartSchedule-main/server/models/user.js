import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const userSchema = new Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    userName: {
        type: String,
        required: true
    },
    token: {
        type: String
    },
    updatedAt: {
        type: Date
    },
    role: {
        type: String,
        default: "user"
    },
    isAdmin: {
        type: Boolean,
        default: false
    }
});

const User = mongoose.model('users', userSchema)

export default User;