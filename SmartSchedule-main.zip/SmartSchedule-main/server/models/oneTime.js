import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const oneTimeSchema = new Schema({
    teacherID: {
        ref: 'teacher',
        type: Schema.Types.ObjectId
    },
    groupID: {
        ref: 'groups',
        type: Schema.Types.ObjectId
    },
    groupName: String,
    date: Date,
    lessonType: String,
    isChecked: {
        type: Boolean,
        default: false
    },
    comment: {
        type: String
    },
    hours: {
        type:Number,
        default: 1
    },
    teacherName: String

})

const OneTime = mongoose.model('oneTime', oneTimeSchema);
export default OneTime;