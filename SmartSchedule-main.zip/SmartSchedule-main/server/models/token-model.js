import Mongoose from 'mongoose';
const Schema = Mongoose.Schema

const tokenSchema = new Schema({
   user: {
       type: Schema.Types.ObjectId,
       ref: 'users'
   },
   refreshToken: {
       type: String,
       required: true
   },
   browserHash: {
       type: String,
       required: true
   }
});

const Token = Mongoose.model('token', tokenSchema)

export default Token;