import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const studentSchema = new Schema({
    groupId: [{
        ref: 'groups',
        type: Schema.Types.ObjectId
    }],
    name: String
})

const Student = mongoose.model('students', studentSchema);
export default Student;