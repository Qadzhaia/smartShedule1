import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const groupSchema = new Schema({
    teacher: {
        ref: 'users',
        type: Schema.Types.ObjectId
    },
    name: String,
    isActive: {
        default: true,
        type: Boolean
    },
    lessons: [{
        ref: 'lessons',
        type: Schema.Types.ObjectId
    }],
    students: [{
        ref: 'students',
        type: Schema.Types.ObjectId
    }]
})

const Group = mongoose.model('groups', groupSchema)

export default Group;