import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const lessonSchema = new Schema({
    groupId : {
        ref: 'groups',
        type: Schema.Types.ObjectId
    },
    date: Date,
    hours: {
        type:Number,
        default: 1
    },
    attendance: [{
        studentId : {
            ref: 'students',
            type: Schema.Types.ObjectId
        },
        presence: Boolean
    }],
    isChecked: {
        type: Boolean,
        default: false
    },
    teacher: {
        ref: 'users',
        type: Schema.Types.ObjectId
    }
})

const Lesson = mongoose.model('lessons', lessonSchema);
export default Lesson;