import jwt from 'jsonwebtoken';
import keys from '../config/keys.js';
import Token from '../models/token-model.js';

const TokenService = {
    generateToken: (payload) => {
     
        const accessToken = jwt.sign(payload, keys.jwt_access, {expiresIn: '15m'})
        const refreshToken = jwt.sign(payload, keys.jwt_refresh, {expiresIn: '30d'})
        return {
            accessToken,
            refreshToken
        }
    },
    validateAccessToken: (token) => {
        try {
            const userData = jwt.verify(token, keys.jwt_access);
            return userData;
        } catch (e) {
            return null;
        }
    },
    validateRefreshToken: (token) => { 
        try {
            const userData = jwt.verify(token, keys.jwt_refresh);
            return userData;
        } catch (e) {
            return null;
        }
    },
    saveToken: async (userID, browserHash ,refreshToken) => {
        const tokenData = await Token.findOne({user: userID, browserHash: browserHash})
        if(tokenData){
            tokenData.refreshToken = refreshToken;
            return tokenData.save();
        }
        const token = await Token.create({user: userID, browserHash: browserHash, refreshToken: refreshToken})
        return token
    },
    removeToken: async (refreshToken) => {
        const tokenData = await Token.deleteOne({refreshToken})
        return tokenData;
    },

    findToken: async (refreshToken) => {
        const tokenData = await Token.findOne({refreshToken: refreshToken})
        return tokenData;
    }
}

export default TokenService;
