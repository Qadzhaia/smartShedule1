import moment from "moment"

const LessonService = {
    createPeriod: ( currentMonth = new Date().getMonth(), currentYear = new Date().getFullYear() ) => {
        const period = {date: 
            {
                "$gte": moment(`${currentYear}-${currentMonth}`).format(),
                "$lt": moment(`${currentYear}-${currentMonth}`).add(1, 'month').format()
            }
        }
        return period
    }
}

export default LessonService