import ApiError from "../exceptions/api-error.js";
import User from "../models/user.js";
import TokenService from "./token-service.js";

const UserService = {
    refresh: async (refreshToken, browserHash) => {
	    
        if (!refreshToken) {
            throw ApiError.UnauthorizedError();
        }
        const userData = TokenService.validateRefreshToken(refreshToken);
        const tokenFromDb = await TokenService.findToken(refreshToken);
	   
        if (!userData || !tokenFromDb) {
            throw ApiError.UnauthorizedError();
        }

        const user = await User.findById(userData.userID);
        
        const userDto = {
            email:user.email,
	        userID: user._id,
            userName: user.userName,
            role: user.role,
            isAdmin: user.isAdmin ? user.isAdmin : false
        }
    
        const tokens = TokenService.generateToken({...userDto});
    
        await TokenService.saveToken(userDto.userID, browserHash, tokens.refreshToken);
        return {...tokens, user: userDto}
    },
    logout: async (refreshToken) => {
        const token = await TokenService.removeToken(refreshToken);
        return token;
    }
}

export default UserService;
