import express from 'express';
import GroupController from '../controllers/group.js';
import passport from 'passport';

const router = express.Router();

router.get('/search/:keyword', passport.authenticate('jwt', {session:false}), GroupController.findMatchGroups);
router.get('/archived', passport.authenticate('jwt', {session:false}), GroupController.getArchived);
router.get('/current/:id/:month/:year', passport.authenticate('jwt', {session:false}), GroupController.getCurrentGroup);

router.post('/create',passport.authenticate('jwt', {session:false}) ,GroupController.createGroup);
router.post('/all', passport.authenticate('jwt', {session:false}), GroupController.getGroupsForCheckIn);
router.post('/addstudent',passport.authenticate('jwt', {session:false}) , GroupController.addStudentToGroup);
router.post('/archive', passport.authenticate('jwt', {session:false}), GroupController.setArchived);
router.post('/unarchive', passport.authenticate('jwt', {session:false}), GroupController.setUnArchived);

router.put('/teacher/change/:id', passport.authenticate('jwt', {session:false}), GroupController.changeTeacher);
router.put('/change/name/:id', passport.authenticate('jwt', {session:false}), GroupController.changeGroupName);

router.delete('/:id', passport.authenticate('jwt', {session:false}), GroupController.deleteGroup);

export default router;