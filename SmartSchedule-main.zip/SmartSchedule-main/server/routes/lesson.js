import express from 'express';
import LessonController from '../controllers/lesson.js';
import passport from 'passport';

const router = express.Router();

router.post('/create', passport.authenticate('jwt', {session:false}) ,LessonController.create);
router.put('/:id', passport.authenticate('jwt', {session:false}) ,LessonController.updateAttandance);
router.put('/hours/:id', passport.authenticate('jwt', {session:false}) ,LessonController.updateHours);
router.put('/status/:id', passport.authenticate('jwt', {session:false}) ,LessonController.updateCheckStatus);
router.delete('/:id', passport.authenticate('jwt', {session:false}) ,LessonController.deleteLesson);

router.get('/count-lessons/:teacher/:month/:year', LessonController.countTeacherHours);
router.get('/count-all-lessons/:month/:year', LessonController.getAllTeacherHours);

export default router