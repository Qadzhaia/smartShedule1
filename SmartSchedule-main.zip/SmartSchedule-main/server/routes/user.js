import express from 'express';
import UserController from '../controllers/user.js';
import passport from 'passport';

const router = express.Router();

router.get('/', passport.authenticate('jwt', {session:false}), UserController.checkUser);
router.get('/teacher/all', passport.authenticate('jwt', {session:false}), UserController.getAllTeacher);
router.get('/search/:keyword', passport.authenticate('jwt', {session:false}), UserController.getMatchUser);

router.delete('/:id', passport.authenticate('jwt', {session:false}), UserController.deleteUser);

export default router;