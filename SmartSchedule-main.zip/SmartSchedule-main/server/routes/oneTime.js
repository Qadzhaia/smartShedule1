import express from 'express';
import passport from 'passport';
import OneTimeController from '../controllers/oneTime.js';

const router = express.Router();

router.get('/get-by-teacher/:id/:mounth', passport.authenticate('jwt', {session:false}), OneTimeController.getByTeacher);

router.post('/create', passport.authenticate('jwt', {session:false}), OneTimeController.create);
router.post('/change-check-status/:id', passport.authenticate('jwt', {session:false}), OneTimeController.changeCheckStatus);

router.delete('/:id', passport.authenticate('jwt', {session:false}) ,OneTimeController.deleteOneTime);



export default router;