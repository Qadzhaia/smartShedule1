import express from 'express';
import passport from 'passport';
import StudentController from '../controllers/student.js';

const router = express.Router();

router.get('/', passport.authenticate('jwt', {session:false}) ,StudentController.getAllStudent);
router.get('/search/:keyword', passport.authenticate('jwt', {session:false}) ,StudentController.findMatchStudents);

router.post('/create', passport.authenticate('jwt', {session:false}), StudentController.createStudent);
router.post('/deletefromgroup', passport.authenticate('jwt', {session:false}) ,StudentController.deleteGroup);

router.delete('/:id', passport.authenticate('jwt', {session:false}), StudentController.deleteStudent);

export default router  