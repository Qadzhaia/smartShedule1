import Group from "../models/group.js";
import Student from "../models/student.js";
import LessonService from "../service/lesson-service.js";
import errorHandler from "../utils/errorHandler.js";

export default {
    createGroup: async function (req, res) {
        const groupName = req.body.name
        const teacherId = req.body.teacherId
        const group = await new Group({
            name: groupName,
            teacher: teacherId,
            isActive: true
        }).save()
        try {
            res.status(201).json(group)
        } catch (e) {
            errorHandler(res, e);
        }
    },

    getGroupsForCheckIn: async function (req, res) {
        try {
            if(req.user) {
                let checkStatus = {};

                if(req.body.checkStatus === 'checked') {
                    checkStatus = {isChecked: true}
                }else if(req.body.checkStatus === 'unchecked'){
                    checkStatus = {isChecked: false}
                }

                const period = LessonService.createPeriod(req.body.month);

                let groupParams;
                if(req.user.isAdmin) {
                    groupParams = req.body.teacherId ? {teacher: req.body.teacherId} :  {}
                } else {
                    groupParams = {teacher: req.user.id}
                }

                const groups = await Group.find(groupParams)
                    .populate({path: 'lessons', match: period , options: {sort: {date: 1},
                    filter: checkStatus }})
                    .populate('students')
                    .populate({ path: 'teacher', select: 'userName' })

                res.status(200).json(groups)

            }else{
                res.status(403).json({message: "Недостаточно прав"})
            }
        } catch (e) {
            errorHandler(res, e);
        }
    },
    findMatchGroups: async function (req, res) {
        try {
            const groupsList = await Group.find({name: {$regex : new RegExp(req.params.keyword)}})
            res.status(200).json(groupsList);
        } catch (e) {
            errorHandler(res, e)
        }
    },
    addStudentToGroup: async function (req, res) {
        try {
            await Student.findByIdAndUpdate(req.body.studentID,
                {$push:{groupId: req.body.groupID}});

            await Group.findByIdAndUpdate(req.body.groupID,
                {$push:{students: req.body.studentID}
                })

            res.status(200).json({message: "Студент добавлен в группу"});
        } catch (e) {
            errorHandler(res, e)
        }
    },
    setArchived: async function (req, res) {
        try {
            await Group.findByIdAndUpdate(req.body.groupID,
                {isActive: false})
            res.status(200).json({message: "Группа заархивирована"});
        } catch (e) {
            errorHandler(res, e)
        }
    },
    getArchived: async function (req, res) {
        try {
            if(req.user.isAdmin) {
                const archivedGroup = await Group.find({isActive: false});
                res.status(200).json(archivedGroup);
            } else {
                res.status(403).json({message: "Недостаточно прав для просмотра данной страницы"});
            }
        } catch (e) {
            errorHandler(res, e)
        }
    },
    deleteGroup: async function (req, res) {
        try {
            if(req.user.isAdmin) {
                await Group.findByIdAndRemove(req.params.id);
                res.status(200).json({message: "Группа Удалена"});
            } else {
                res.status(403).json({message: "Недостаточно прав для просмотра данной страницы"});
            }
        } catch (e) {
            errorHandler(res, e)
        }
    },
    setUnArchived: async function (req, res) {
        try {
            await Group.findByIdAndUpdate(req.body.groupID,
                {isActive: true})
            res.status(200).json({message: "Группа разархивирована"});
        } catch (e) {
            errorHandler(res, e)
        }
    },
    getCurrentGroup: async function (req, res) {
        try {
            const period = LessonService.createPeriod(req.params.month, req.params.year)

            const groups = await Group.findById(req.params.id)
                .populate({path: 'lessons', match: period , options: {sort: {date: 1}}})
                .populate('students')
                .populate({path: 'teacher', select: 'userName' })

            res.status(200).json(groups)
        } catch (e) {
            errorHandler(res, e)
        }
    },
    changeTeacher: async function (req, res) {
        try{
            await Group.findByIdAndUpdate(req.body.groupID,
                {teacher: req.params.id})
            res.status(200).json({message: "Преподаватель изменён"})
        } catch (e) {
            errorHandler(res, e)
        }
    },
    changeGroupName: async function (req, res) {
        try {
            await Group.findByIdAndUpdate(req.params.id,
                {name: req.body.newName});
            
            res.status(200).json({message: "Имя группы измененно"});
        } catch (e) {
            errorHandler(res, e)
        }
    }
}
