import User from '../models/user.js';
import bcrypt from 'bcrypt';
import TokenService from '../service/token-service.js';
import UserService from '../service/user-service.js';

export default {
    register: 
        async function(req,res,next){
            const candidate = await User.findOne({email: req.body.email.toLowerCase()})
            if(candidate){
                //пользователь найден, отдать ошибку
                res.status(409).json({
                    message: "Email уже занят. Попробуйте другой."
                })
            }else{
                const salt = bcrypt.genSaltSync(8);
                const password = req.body.password;
                const userName = req.body.userName;
                const user = new User({
                    email: req.body.email.toLowerCase(),
                    password: bcrypt.hashSync(password,salt),
                    userName: userName,
                    role: 'teacher'
                })

                try{
                    await user.save()
                    res.status(201).json(user)
                }catch(e){
                    next(e);
                }
            }
        },

        login:
            async function(req,res,next){
                try{
                    if(req.body.password.length<6){
                        res.status(406).json({
                            message: 'Пароль должен быть длиннее 6 символов'
                        })
                    }
                    
                    const candidate = await User.findOne({
                        email: req.body.email.toLowerCase()
                    })
                    if(candidate){
                        //ok. lets check pass
                        const passwordResult = bcrypt.compareSync(req.body.password, candidate.password)
                        if(passwordResult){
                            const user = {
                                email:candidate.email,
                                userID: candidate._id,
                                role: candidate.role,
                                isAdmin: candidate.isAdmin ? candidate.isAdmin : false
                            }

                            const tokens = TokenService.generateToken(user)

                            await TokenService.saveToken(candidate._id, req.fingerprint.hash, tokens.refreshToken);

                            res.cookie('refreshToken', tokens.refreshToken, {maxAge: 30 * 24 * 60 * 60 * 1000, httpOnly: true})
			
                            res.status(200).json({
                                token: `Bearer ${tokens.accessToken}`,
                                userName: candidate.userName,
                                userID: candidate._id,
                                isAdmin: candidate.isAdmin ? candidate.isAdmin : false
                            })
               
                        }else{
                            res.status(403).json({
                                message: 'Неверный пароль'
                            })
                        }
                    }else{
                        //no candidate. error
                        res.status(404).json({
                            message: 'Пользователь не найден.',
                        })
                    }
                }catch(e){
                    next(e);
                }
            },
            refresh: async (req, res,next) => {
                try {
                    const {refreshToken} = req.cookies;
                    const userData = await UserService.refresh(refreshToken, req.fingerprint.hash);

                    res.cookie('refreshToken', userData.refreshToken, {maxAge: 30 * 24 * 60 * 60 * 1000, httpOnly: true})
                    return res.json(userData);
                } catch (e) {
                    next(e);
                }
            },
            logout: async (req, res) => {
                try{
                    const {refreshToken} = req.cookies;
                
                    const token = await UserService.logout(refreshToken);
                    res.clearCookie('refreshToken');
                    return res.json(token);
                } catch (e) {
                    next(e);
                }
            }
}


