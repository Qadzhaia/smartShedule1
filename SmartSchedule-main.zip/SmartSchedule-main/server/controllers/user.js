import User from '../models/user.js'
import errorHandler from '../utils/errorHandler.js'

export default {
    checkUser: 
        async function(req ,res) {
            try {
                const candidate = await User.findOne({token: req.headers.authorization});
                if(candidate){
                    res.status(200).json({user: {token: candidate.token, email: candidate.email, userName: candidate.userName, isAdmin: candidate.isAdmin, userID: candidate._id}})
                }else{
                    res.status(403).json({message: "user not found"})
                }
            } catch (e) {
                errorHandler(res, e)
            }
           
    },
    getAllTeacher:
        async function(req, res) {
            try {
                if(req.user.isAdmin) {
                    const teachers = await User.find({role: "teacher"});
                    res.status(200).json(teachers)
                } else {
                    res.status(403).json({message: "Недостаточно прав"})
                }

            } catch (error) {
                errorHandler(res, e)
            }
        },
    getMatchUser: 
        async function (req, res) {
            if(req.user.isAdmin){
                try {
                    const userList = await User.find({userName: {$regex : new RegExp(req.params.keyword)}})
                    res.status(200).json(userList);
                } catch (e) {
                    errorHandler(res, e)
                }
            }else {
                res.status(401).json({message: 'Access denied'})
            }
        },
    deleteUser:
        async function (req, res) {
            if(req.user.isAdmin) {
                try {
                    await User.deleteOne({_id: req.params.id})
                    res.status(200).json({message: "Пользователь успешно стёрт"});
                } catch (e) {
                    errorHandler(res, e)
                }
            }
        }

}