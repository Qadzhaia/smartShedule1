import Group from "../models/group.js";
import OneTime from "../models/oneTime.js";
import LessonService from "../service/lesson-service.js";
import errorHandler from "../utils/errorHandler.js";

export default {
    create: async function (req,res) {
        try {
            let group = false;
            if(req.body.groupID.length > 0) {
                group = await Group.findById(req.body.groupID)
            }

            const oneTime = await new OneTime({
                teacherID: req.body.teacherID,
                groupID: group ? req.body.groupID : null,
                date: req.body.date,
                lessonType: req.body.lessonType,
                groupName: group ? group.name : "Пробное",
                comment: req.body.comment,
                hours: req.body.hours,
                teacherName: req.body.teacherName
            }).save()
            res.status(200).json(oneTime)
        } catch (e) {
            errorHandler(res,e)
        }
    },
    getByTeacher: async function (req, res) {

        try {
            let oneTimerParams = {};
            if(req.params.id === "1111"){   
                oneTimerParams= {}
            } else {
                oneTimerParams = {teacherID: req.params.id}
            }

            const period = LessonService.createPeriod(req.params.mounth)

            const oneTimers = await OneTime.find(oneTimerParams).find(period)

            res.status(200).json(oneTimers);
        } catch (e) {
            errorHandler(res,e)
        }
    },
    deleteOneTime: async function (req,res) {
        try {
            await OneTime.deleteOne({_id: req.params.id});
            res.status(200).json({message: "Вантайм успешно удален"})
        } catch (e) {
            errorHandler(res,e)
        }
    },
    changeCheckStatus: async function (req, res) {
        try {
            if(req.user.isAdmin){
                await OneTime.findByIdAndUpdate(req.params.id, {
                    isChecked: req.body.isChecked
                })

                res.status(200).json({message: "Статус отметки изменен"})
            } else {
                res.status(403).json({message: "Недостаточно прав"})
            }
        } catch (e) {
            errorHandler(res,e)
        }
    }
}