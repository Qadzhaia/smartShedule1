import Group from "../models/group.js";
import Student from "../models/student.js";
import errorHandler from "../utils/errorHandler.js";

export default {
    createStudent: async function (req, res) {
        const groupId = req.body.groupId ? req.body.groupId.length > 1 ? [req.body.groupId] : [] :[]
        try {
            const student = await new Student({
                name: req.body.name,
                groupId: groupId
            }).save()

            if(groupId){
                await Group.findByIdAndUpdate(groupId,
                   {$push:{students: student._id}
                })

            }
            res.status(200).json(student)
        } catch (e) {
            errorHandler(res, e)
        }
    },
    findMatchStudents: async function (req, res) {
        try {
            const studentsList = await Student.find({name: {$regex : new RegExp(req.params.keyword)}})
            res.status(200).json(studentsList);
        } catch (e) {
            errorHandler(res, e)
        }
    },
    deleteGroup: async function (req, res) {
        try {
            await Group.findByIdAndUpdate(req.body.groupID,
                {$pull: {students: req.body.studentID}});

            await Student.findByIdAndUpdate(req.body.studentID,
                {$pull:{groupId: req.body.groupID}});

            res.status(200).json({message: "Студент удален из группы"});
        } catch (e) {
            errorHandler(res, e)
        }
    },
    getAllStudent: async function (req, res) {
        try {
            if(req.user.isAdmin) {
                const students = await Student.find({})
                res.status(200).json(students)
            } else {
                res.status(403).json({message: "Недостаточно прав для просмотра данной страницы"});
            }
        } catch (e) {
            errorHandler(res, e)
        }
    },
    deleteStudent: async function(req, res) {
        try{
            if(req.user.isAdmin) {
                await Group.findOneAndUpdate({students: req.params.id},
                    {$pull: {students: req.params.id}})

                await Student.findByIdAndRemove(req.params.id)
                res.status(200).json({message: "Студент удален"});
            } else {
                res.status(403).json({message: "Недостаточно прав для просмотра данной страницы"});
            }
        } catch (e) {
            errorHandler(res, e)
        }
    }
}