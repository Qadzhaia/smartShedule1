import Group from "../models/group.js"
import Lesson from "../models/lesson.js"
import OneTime from "../models/oneTime.js"
import LessonService from "../service/lesson-service.js"
import errorHandler from "../utils/errorHandler.js"


export default {
    create: async function (req, res) {
        try {
            const lesson = await new Lesson({
                groupId: req.body.groupId,
                date: req.body.date,
                hours: req.body.hours,
                teacher: req.body.teacherID
            }).save()

            await Group.findByIdAndUpdate(req.body.groupId, {$push: {lessons:lesson._id}})
            res.status(200).json(lesson)
        } catch (e) {
            errorHandler(res,e)
        }
    },
    updateAttandance: async function (req, res) {
        try {
            const lesson = await Lesson.findById(req.params.id)
            const mathcedObj = lesson.attendance.filter(el=>{
                return el.studentId == req.body.studentsAttandance.studentId
            })

            const isChecked = mathcedObj.length > 0 
            if(isChecked){
                await lesson.updateOne({$pull:{attendance: {studentId: mathcedObj[0].studentId}}}, {multi:true} )
            }

            await lesson.updateOne({$push:{attendance: req.body.studentsAttandance}})

            await lesson.save()

            res.status(200).json({message: lesson})
        } catch (e) {
            errorHandler(res,e)
        }
    },
    updateHours: async function (req, res) {
        try {
            await Lesson.findByIdAndUpdate(req.params.id,
                {hours: req.body.hours});
            
            res.status(200).json({message: "hours are changed"})
        } catch (e) {
            errorHandler(res,e)
        }
    },
    updateCheckStatus: async function (req, res) {
        try {
            await Lesson.findByIdAndUpdate(req.params.id,
                {isChecked: req.body.isChecked});
            
            res.status(200).json({message: "status is changed"})
        } catch (e) {
            errorHandler(res,e)
        }
    },
    deleteLesson: async function(req, res) {
        try {
            await Group.findOneAndUpdate({lessons: req.params.id},
                {$pull: {lessons: req.params.id}})
            
            await Lesson.deleteOne({_id: req.params.id})

            res.status(200).json({message: "Урок удален"});
        } catch (e) {
            errorHandler(res,e)
        }
    },
    countTeacherHours: async function(req, res) {
        try {
            const period = LessonService.createPeriod(req.params.month, req.params.year);
            const lessons = await Lesson.find({teacher: req.params.teacher}).find({isChecked: true}).find(period);
            const oneTimers = await OneTime.find({teacherID: req.params.teacher}).find(period).find({isChecked: true});
            const hours = lessons.reduce(((acc,cur)=>acc+cur.hours),0)
            const oneTimersHours = oneTimers.reduce(((acc,cur)=>acc+cur.hours),0)

            res.status(200).json({message: hours + oneTimersHours})
        } catch (e) {
            errorHandler(res,e)
        }
    },
    getAllTeacherHours: async function(req, res) {
        try {
            const period = LessonService.createPeriod(req.params.month, req.params.year);
            const lessons = await Lesson.find(period).find({isChecked: true}).populate('teacher');
            const oneTimersList = await OneTime.find(period).find({isChecked: true}).populate('teacher');
            
            let oneTime_teachersList = []
            let oneTime_hoursList = []

            oneTimersList.forEach(el => {
                if(!oneTime_teachersList.includes(el.teacherName)){
                    oneTime_teachersList.push(el.teacherName)
                }
            })

            oneTime_teachersList.sort().forEach(el => {
                oneTime_hoursList.push(
                    {
                        userName: el,
                        hours: oneTimersList.filter(ls=>ls.teacherName === el).reduce(((acc, cur)=>acc+cur.hours),0)
                    }
                )
            })

            let teacherList = [];
            let hoursList = []
            lessons.forEach(el => {
                if(!teacherList.includes(el.teacher.userName)){
                    teacherList.push(el.teacher.userName)
                }
            })

            teacherList.sort().forEach(el => {
                hoursList.push(
                    {
                        userName: el,
                        hours: lessons.filter(ls=>ls.teacher.userName === el).reduce(((acc, cur)=>acc+cur.hours),0)
                    }
                )
            })

            const finalList = hoursList.map(el=>{
                oneTime_hoursList.map(otel => {
                    if(el.userName === otel.userName) {
                        el.hours += otel.hours;
                    }
                })
                return el
            })

            res.status(200).json(finalList)

        } catch (e) {
            errorHandler(res,e)
        }
    }
}