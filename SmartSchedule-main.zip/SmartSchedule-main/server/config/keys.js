const keys = {
    mongo_uri: "mongodb+srv://coderApp:coder@cluster0.v1fi5.mongodb.net/Cluster0?retryWrites=true&w=majority",
    jwt: 'pi-1314',
    jwt_access: 'pi-1314',
    jwt_refresh: 'pi-314159'
}

export default keys