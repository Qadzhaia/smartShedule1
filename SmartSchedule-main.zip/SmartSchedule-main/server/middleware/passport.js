import keys from '../config/keys.js';
import { Strategy } from 'passport-jwt';
import { ExtractJwt } from 'passport-jwt';
import User from '../models/user.js';

const JwtStratagy = Strategy;

const options = {
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey: keys.jwt
}

const passportMiddleware = passport => {
    passport.use(
        new JwtStratagy(options, async (payload, done)=>{
            try {
                const user = await User.findById(payload.userID).select('email role isAdmin')
                if(user) {
                    done(null, user)
                } else {
                    done(null, false)
                }
            }catch(e){
                console.log(e)
            }        
        })
    )
}

export default passportMiddleware;
