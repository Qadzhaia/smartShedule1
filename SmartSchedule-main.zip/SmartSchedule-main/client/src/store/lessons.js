
const defaultState = {
    month: new Date().getMonth()+1,
    lessonsList: [],
    onlyUnchecked: false,
    isLoading: false
}

export const lessonsReducer = (state = defaultState, action) => {
    switch (action.type) {
        case "SET_MONTH":
            return {...state, month: action.payload}
        case "CHANGE_CHECK_STATUS":
            return {...state, onlyUnchecked: action.payload}
        case "SET_LESSONS_LIST":
            return {...state, lessonsList: action.payload}
        case "SET_LOADING":
            return {...state, isLoading: action.payload}
        case "REMOVE_FROM_LESSONS_LIST":
            return {...state, lessonsList: state.lessonsList.filter(el=>el._id !== action.payload)}
        

        default:
            return state
    }
}