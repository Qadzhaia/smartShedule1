import $api from "../../service/api-service";

export const FetchLessons = (month, teacherId = "") => {
    return dispatch => {
        dispatch({type: "SET_LOADING", payload: true})
        $api.post('/group/all', {month, teacherId})
            .then((response => {
                dispatch({type: 'SET_LESSONS_LIST', payload: response.data});
            }))
            .catch(err=>{
                if(err.response.status === 401) {
                    dispatch({type: "SET_UNAUTHORIZED"});
                }
            })
            .finally(()=>{
                dispatch({type: "SET_LOADING", payload: false})
            })
    }
}

export const SaveAttandance = (lessonId, studentsAttandance) => {
    return dispatch => {
        $api.put('/lesson/'+lessonId, {studentsAttandance})
            .catch(err=>{
                if(err.response.status === 401) {
                    dispatch({type: "SET_UNAUTHORIZED"});
                }
            })
    }
}