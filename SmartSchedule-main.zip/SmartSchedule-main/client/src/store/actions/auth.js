import $api from "../../service/api-service"

export const loginUser = (email, password) => {
    return dispatch => {
        $api.post('/auth/login', {email, password})
            .then((response => {
                localStorage.setItem('token', response.data.token);
                const user = setUserToLC(response.data);
                dispatch({type: 'SET_AUTHORIZED', payload: user});
            }))
            .catch(error=>{
                console.log(error);
            })
    }
}

const setUserToLC = response => {
    const user = {
        isAdmin: response.isAdmin,
        userName: response.userName,
        userID: response.userID
    }
    localStorage.setItem('user', JSON.stringify(user));
    return user;
}
