import { applyMiddleware, combineReducers, createStore } from "redux";
import { currentUserReducer } from "./currentUser";
import { lessonsReducer } from "./lessons"
import thunk from 'redux-thunk'

const reducers = combineReducers({
    currentUser: currentUserReducer,
    lessons: lessonsReducer
})

export const store = createStore(reducers, applyMiddleware(thunk))