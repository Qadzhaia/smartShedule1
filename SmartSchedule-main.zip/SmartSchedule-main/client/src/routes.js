import React from 'react'
import {Switch, Route, Redirect} from 'react-router-dom'
import MainPage from './pages/mainPage';

import AuthPage from './pages/authPage.js'
import LessonsPage from './pages/lessonsPage';
import CreatingPage from './pages/creatingPage';
import LessonManagementPage from './pages/lessonManagementPage';
import ArchivePage from './pages/archivePage';
import { useSelector } from 'react-redux';

const Routes = () => {
  const currentUserState = useSelector(state => state.currentUser);

  return (
    <Switch>
        <Route path="/" component={MainPage} exact />
        {currentUserState.isLoggedIn && <Route path="/lessons" component={LessonsPage} /> }
        {currentUserState.isLoggedIn && currentUserState.currentUser.isAdmin && <Route path="/creation" component={CreatingPage} />}
        {!currentUserState.isLoggedIn && <Route path="/login" component={AuthPage} />}
        {currentUserState.currentUser!==null && currentUserState.currentUser.isAdmin && <Route path="/lessons-check" component={LessonManagementPage} />}
        {currentUserState.currentUser!==null && currentUserState.currentUser.isAdmin && <Route path="/archive" component={ArchivePage} />}
        <Redirect to="/" />
    </Switch>
  )
}
export default Routes
