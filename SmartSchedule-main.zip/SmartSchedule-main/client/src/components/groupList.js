import React, { useCallback } from 'react';
import { useSelector } from 'react-redux';
import GroupElem from './groupElem.js';


const GroupList = ({ isManager = false }) =>{
    const lessons = useSelector(state => state.lessons) 

    const ArrayFiltered = useCallback(() => {
        if( !Array.isArray(lessons.lessonsList)) {
           return []
        }
        return lessons.lessonsList.filter((el)=>el.isActive)
            .filter(el=> {
                if (!lessons.onlyUnchecked) {
                    return true;
                }
                return Array.isArray(el.lessons) && el.lessons.length > 0 &&
                    el.lessons.filter(lesson => !lesson.isChecked).length > 0
        });
    },[lessons])

    const lessonsArr = ArrayFiltered();

    return(
        <div>
            { lessonsArr.map(el => 
                <GroupElem key={el._id} initGroupData={el} isManager={isManager}/>
            )} 
        </div>
    )
}

export default GroupList