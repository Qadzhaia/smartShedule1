import React, { useEffect } from "react";
import useFetch from '../hooks/useFetch.js';

const StudentListItem = ({studentName, studentId, updateFunc}) => {
    const [{response}, doFetch] = useFetch('/student/'+studentId);

    const delClickHandler = () => {
        doFetch({
            method: "delete"
        })
    }

    useEffect(()=>{
        if(!response) {
            return
        }
        updateFunc(studentId)
        console.log(response)
    },[response, studentId, updateFunc])

    return(
        <div className="group-list__item">
            <span className="group-item__name">{studentName}</span>
            <button onClick={delClickHandler}>x</button>
        </div>
    )
}

export default StudentListItem;