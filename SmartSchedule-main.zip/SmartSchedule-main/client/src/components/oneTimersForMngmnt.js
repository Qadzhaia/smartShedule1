import React, {  useEffect, useState } from "react";
import useFetch from '../hooks/useFetch.js';
import DeleteOneTimeBtn from "./deleteOneTimeBtn.js";
import OneTimeCheckbox from "./oneTimeCheckbox.js";
import Loading from "./loading.js";
   
const OneTimersForMngmnt = ({teacherID, onlyUnchecked, currentMounth=1 }) => {
    const [lessons, setLessons] = useState([]);
    const [{response, isLoading}, doFetch] = useFetch('/onetime/get-by-teacher/'+teacherID+"/"+currentMounth);
    const [open, setOpen] = useState("");

    const openHandler = () => {
        setOpen(p=>p === "" ? "onetime__list--mngmnt--opened": "")
    }

    useEffect(()=>{
        doFetch();
    },[doFetch])

    useEffect(()=>{
        if(!response) {
            return;
        }
        let dataArray = response
        if(onlyUnchecked) {
            dataArray = response.filter(el=>!el.isChecked)
        }
        setLessons(dataArray)
    },[response, onlyUnchecked])

    return(
        <div>
            {isLoading && <Loading />}
            <div className={`onetime__list--mngmnt ${open}`}>
                {
                    lessons.map(el=>{
                        return (
                            <div className="onetime-list__item" key={el._id}>
                                <DeleteOneTimeBtn key={el._id} updateFunc={doFetch} onetimeID={el._id}/>
                                <div className="onetime-list__date">{el.date.slice(5, 10)}</div>
                                <div className="onetime-list__lesson-type">{el.lessonType === "first" ? "Пробное" : "Замена"}</div>
                                <div className="onetime-list__group-name">{el.groupName}</div>
                                <div className="onetime-list__group-name">{el.teacherName}</div>
                                <div><i>{el.comment}</i></div>
                                <div>
                                    <i>{el.hours}</i>
                                </div>
                                <OneTimeCheckbox oneTimeID={el._id} isChecked={el.isChecked}/>
                            </div>
                        )
                    })
                }
            </div>
            {lessons.length > 6 && <button onClick={openHandler}> {open==="" ? "Показать все" : "Свернуть"}</button>}
        </div>
    )
}

export default OneTimersForMngmnt;