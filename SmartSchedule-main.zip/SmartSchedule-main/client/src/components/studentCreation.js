import React, {useCallback, useEffect, useState} from 'react';
import useFetch from '../hooks/useFetch.js'

const StudentCreation = () => {
    const [{response}, doFetch] = useFetch('/student/create');
    const [userData, setUserData] = useState({
        userName: "", groupId: ""
    })

    const [message, setMessage] = useState("")

    const changeHandler = useCallback(({target})=>{
        setUserData({...userData, [target.name]: target.value})
    },[userData])



    const studentCreateHandler = useCallback(()=>{
        doFetch({
            method: 'post',
            data: {
                name: userData.userName,
                groupId: userData.groupId
            }
          })

    },[userData, doFetch])

    useEffect(()=>{
        if(!response){
            return
        }
        console.log(response)
        setMessage(
            <>
                <p>Студент <b>{response.name}</b> добавлен к группе <b>{response.groupId[response.groupId.length-1]}</b></p>
            </>
        )
        document.getElementById("create_user_input").value = ""
    },[response])

    return(
        <div className="group-creation">
            <div>
                <h2>Создание студента</h2>
                <div className="creating-page__input-wrap"> 
                    <input autoComplete='off' type="text" placeholder="Имя студента" name="userName" id="create_user_input" onChange={changeHandler}/>
                </div>
                <div className="creating-page__input-wrap">
                    <input autoComplete='off' type="text" placeholder="id группы, если уже есть" name="groupId" onChange={changeHandler}/>
                </div>
                <div className="creating-page__input-wrap">
                    <button className="yc_button" onClick={studentCreateHandler}>Создать</button>
                </div>
            </div>
            <div className="group-creation__log student-creating">
                <h3>Логи</h3>
                <div>
                    {message}
                </div>
            </div>
        </div>
    )
}

export default StudentCreation;