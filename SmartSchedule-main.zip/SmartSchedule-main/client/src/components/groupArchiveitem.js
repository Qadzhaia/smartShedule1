import React, { useEffect } from "react";
import useFetch from '../hooks/useFetch.js';
import UnArchiveBtn from "./unArchiveBtn.js";

const GroupArchiveItem = ({ gruopName, groupId, updateFunc }) => {
    const [{response}, doFetch] = useFetch('/group/'+groupId);

    const deleteBtnHandler = () => {
        doFetch({
            method: "delete"
        })
    }

    useEffect(()=>{
        if(!response){
            return;
        }
        updateFunc(groupId);
    },[response, updateFunc, groupId])

    return(
        <div className="group-list__item">
            <span className="group-item__name">{gruopName}</span>
            <button onClick={deleteBtnHandler}>x</button>
            <UnArchiveBtn updateFunc={updateFunc} groupID={groupId}/>
        </div>
    )
}

export default GroupArchiveItem