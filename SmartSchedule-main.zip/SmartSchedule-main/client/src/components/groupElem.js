import React, { useCallback, useEffect, useState } from "react";
import AddToGroup from "./addToGroupComponent";
import ArchiveGroupBtn from "./archiveGroupBtn";
import LessonCreation from "./lessonCreation";
import StudentsList from "./studentsListComponent";
import useFetch from '../hooks/useFetch.js';
import Loading from "./loading";
import LessonsListComponent from "./lessonsListComponent";
import TeacherChange from "./teacherChange";
import GroupNameComponent from "./groupName";
import { useDispatch, useSelector } from "react-redux";

const GroupElem = ({initGroupData, isManager, year = new Date().getFullYear()}) => {
    const lessonsState = useSelector(state=>state.lessons)
    const [{response, isLoading}, doFetch] = useFetch(`/group/current/${initGroupData._id}/${lessonsState.month}/${year}`);
    const [groupData, setGroupData] = useState(initGroupData);
    const dispatch = useDispatch()

    const updateFunction = useCallback(() => {
        doFetch();
    },[doFetch])

    useEffect(()=>{
        setGroupData(initGroupData);
    },[initGroupData])

    const filterUnchecked = useCallback(() => {
        if(!lessonsState.onlyUnchecked) {
            return groupData.lessons
        }

        return groupData.lessons.filter(el => !el.isChecked)
        
    }, [groupData, lessonsState.onlyUnchecked]);

    const filteredLessons = filterUnchecked();
    
    useEffect(()=>{
        if(!response) {
            return;
        }

        if(lessonsState.onlyUnchecked && response.lessons.filter(lesson=>!lesson.isChecked).length <= 0) {
            return dispatch({type: "REMOVE_FROM_LESSONS_LIST", payload:response._id});
        }

        setGroupData(response);
    },[response, dispatch, lessonsState.onlyUnchecked, groupData._id])



    return (
        <div className="group-wrap" key={initGroupData._id+"lesson"}>
            <div className="group__mgt">
                <ArchiveGroupBtn updateFunc={updateFunction} groupID={groupData._id}/>
                {isLoading && <Loading />}
                {isManager && 
                    <div className="group__teacher">
                        <TeacherChange groupTeacher={groupData.teacher} groupID={groupData._id} updateFunction={updateFunction}/>
                    </div>}
            </div>
            {isManager ? 
                <GroupNameComponent updateFunction={updateFunction} groupID={groupData._id} groupName={groupData.name}/> : 
                <h3 className="group__name">{groupData.name}</h3>   
            }
            <div className="group-block">
                <div>
                    <StudentsList updateFunc={updateFunction} isManager={isManager} groupID={groupData._id} studnets={groupData.students} />
                    {isManager && <AddToGroup updateFunc={updateFunction} groupID={groupData._id}/>}
                </div>
                <LessonsListComponent updateFunction={updateFunction} isManager={isManager} students={groupData.students} lessons = {filteredLessons} />
                <LessonCreation updateFunction={updateFunction} groupData={groupData}/>
            </div>
        </div>
    )
}

export default GroupElem;