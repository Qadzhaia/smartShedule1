import React from "react";
import AttandanceSelect from "./attandanceSelect";
import LessonDelComponent from "./lessonDelComponent";
import LessonHoursComponent from "./lessonHoursComponent";
import LessonsCheckComponent from "./lessonsCheckComponent";

const LessonsListComponent = ({ lessons, isManager, updateFunction, students }) => {
    return(
        lessons.map(lessonData => {
            return(
                <div className="lesson__item" key={lessonData._id}>
                    <div className="lessons-item__header">
                        <LessonDelComponent isChecked={lessonData.isChecked} updateFunction={updateFunction} lessonId={lessonData._id} />
                        <span className="lesson-item__date">{lessonData.date.slice(5, 10).split("-").reverse().join('.')}</span>
                    </div>
                    <AttandanceSelect students={students} lesson={lessonData} callBackFunc={updateFunction} lessonId={lessonData._id} />
                    <LessonHoursComponent isChecked={lessonData.isChecked} hours={lessonData.hours} lessonID={lessonData._id}/>
                    <LessonsCheckComponent updateFunction={updateFunction} isManager={isManager} isChecked={lessonData.isChecked} lessonID={lessonData._id}/>
                </div>
            )
        })
    )
}

export default LessonsListComponent;