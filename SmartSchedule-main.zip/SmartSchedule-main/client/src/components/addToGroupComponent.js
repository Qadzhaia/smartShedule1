import React, { useEffect, useState } from "react";
import useFetch from '../hooks/useFetch.js';
import AddToGroupBtn from "./addToGroupBtnComponent.js";
import { StudentSearchItem } from "./studentSearch.js";

const AddToGroup = ({groupID, updateFunc}) => {
    const [matchStudent, setMatchStudent] = useState();
    const [urlParams, setUrlParams] = useState('');
    const [addStudentID, setAddStudentID] = useState('');
    const [{response}, doFetch] = useFetch('/student/search/'+urlParams)

    const [searchShow, SetSearchShow] = useState(false)
    const addClickHandler = () => {
        SetSearchShow(!searchShow)
        setMatchStudent("")
    }

    const searchChangeHandler = ({target}) => {
        if(target.value === "") {
            setMatchStudent("");
            return;
        }

        setUrlParams(target.value);
        doFetch();
    }

    useEffect(()=>{
        if(!response) {
            return
        }

        setMatchStudent(response)
    },[response])

    const resultClickHandler = (studentID, studentName) => {
        document.getElementById('addGroupStudentName').value = studentName;
        setMatchStudent("")
        setAddStudentID(studentID);
    }

    return(
        <div className="add-to-group__wrap">
            <div>
                <button className="add-student__btn" onClick={addClickHandler}>Добавить студентов</button>
            </div>
            {searchShow && <div className="student-list-add">
                <input autoComplete="off" placeholder="Имя студента..." id="addGroupStudentName" onChange={searchChangeHandler} type="text"/>
                <AddToGroupBtn updateFunc={updateFunc} groupID={groupID} studentID={addStudentID}/>
                <StudentSearchItem studentsArr={matchStudent} resultClickHandler={resultClickHandler}/>
            </div>}
        </div>
    )
}

export default AddToGroup;