import React, { useEffect } from 'react';
import useFetch from '../hooks/useFetch.js';

const DeleteOneTimeBtn = ({onetimeID, updateFunc}) => {
    const [{response}, doFetch] = useFetch('/onetime/'+onetimeID)

    const deleteClickHandler = () => {
        doFetch({
            method: "delete"
        })
    }

    useEffect(()=>{
        if(!response) {
            return;
        }

        updateFunc();
    },[response, updateFunc])

    return(
        <div className="one-time__delete-btn">
            <button className="lesson-item__remove-btn" onClick={deleteClickHandler}>X</button>
        </div>
    )
}

export default DeleteOneTimeBtn;