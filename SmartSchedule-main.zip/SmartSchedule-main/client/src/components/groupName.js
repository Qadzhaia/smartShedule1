import React, { useEffect, useState } from "react";
import useFetch from '../hooks/useFetch.js';

const GroupNameComponent = ({groupName, groupID, updateFunction}) => {
    const [changeState, setChangeState] = useState(false);
    const [inputData, setInputData] = useState(groupName);
    const [{response}, doFetch] = useFetch('/group/change/name/'+groupID)

    const clickHandler = ({target}) => {
        setChangeState(true)
    }

    const saveGroupName = () => {
        doFetch({
            method: 'put',
            data: {
                newName: inputData
            }
        })
    }

    useEffect(()=>{
        if(!response) {
            return;
        }
        setChangeState(false)
        updateFunction();
    },[response, updateFunction])

    return(
        <div>
            {changeState ?
            <div>
                <input className="group-name__changer" type="text" onChange={({target})=>{setInputData(target.value)}} defaultValue={groupName}/>
                <button onClick={saveGroupName}>✓</button> 
            </div> :
            <h3 className="group__name" onClick={clickHandler} >{groupName}</h3>
            }
            
        </div>
    )
}

export default GroupNameComponent;