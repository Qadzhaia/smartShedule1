import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import {NavLink, Link} from 'react-router-dom'
import TeacherInfo from './teachers-info';

const Topbar = () => {
  const dispatch = useDispatch();
  const currentUserState = useSelector(state => state.currentUser);
  
  return (
    <nav className="navbar navbar-light">
      <div className="container">
        <Link to="/" className="navbar-brand">
          <div className="top-bar__logo-wrap">
            <img src="./img/logo.png" alt="Смэш – платформа для преподаватлей YesCoding"/>
          </div>
        </Link>
        <ul className="nav navbar-nav pull-xs-right">
          {currentUserState.isLoggedIn && currentUserState.currentUser.isAdmin &&
          <li className="nav-item">
            <NavLink to="/creation" className="nav-link" >
              Создать
            </NavLink>
          </li>}
          {currentUserState.isLoggedIn && currentUserState.currentUser.isAdmin &&
          <li className="nav-item">
            <NavLink to="/archive" className="nav-link" >
              Архив и студенты
            </NavLink>
          </li>}
          {currentUserState.isLoggedIn && currentUserState.currentUser.isAdmin &&
          <li className="nav-item">
            <NavLink to="/lessons-check" className="nav-link" >
              Отметить
            </NavLink>
          </li>}
          {currentUserState.isLoggedIn && !currentUserState.currentUser.isAdmin &&
          <li className="nav-item">
            <NavLink to="/lessons" className="nav-link" >
              Уроки
            </NavLink>
          </li>}
          <div className="nav-bar__decor"></div>
          <li className="nav-item nav__user-name">
          {currentUserState.isLoggedIn && <b>{currentUserState.currentUser.userName}</b> }
          </li>
          <li>
            {currentUserState.isLoggedIn && 
            !currentUserState.currentUser.isAdmin &&
            <TeacherInfo teacher={currentUserState.currentUser}/> }
          </li>
          <li className="nav-item sign-btn">
          {currentUserState.isLoggedIn && <button className="exit__btn" onClick={()=>{dispatch({type: 'SET_UNAUTHORIZED'})}} >
              Выход
            </button>}
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default Topbar
