import React, { useCallback, useEffect, useState } from 'react';
import useFetch from '../hooks/useFetch.js';
import DeleteOneTimeBtn from './deleteOneTimeBtn.js';
import OneTimeCreation from './oneTimeCreation.js';

const OneTime = ({teacherID, currentMounth=1}) => {
    const [lessons, setLessons] = useState("");
    const [{response}, doFetch] = useFetch('/onetime/get-by-teacher/'+teacherID+'/'+currentMounth);

    useEffect(()=>{
	    doFetch();
    },[doFetch, currentMounth])

    useEffect(()=>{
        if(!response) {
            return
        }
    },[response])


    const lessonsRender = useCallback((response) => {
        setLessons(
            <div className="onetime__list">
                {
                    response.map(el=>{
                        return (
                            <div className="onetime-list__item" key={el._id}>
                                <div className="one-time__delete-btn">
                                {!el.isChecked && 
                                    <DeleteOneTimeBtn key={el._id} updateFunc={doFetch} onetimeID={el._id}/>
                                }
                                </div>
                                <div>{el.date.slice(5, 10)}</div>
                                <div>{el.lessonType === "test" ? "Пробное" : "Замена"}</div>
                                <div>{el.groupName}</div>
                                <div><i>{el.comment}</i></div>
                                <div>
                                    <i>{el.hours}</i>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
            
        )
    },[doFetch])

    useEffect(()=>{
        if(!response){
            return
        }
        
        lessonsRender(response);
    },[response, lessonsRender])


    return(
        <div className="onetime__wrap">
            {lessons}
            <OneTimeCreation lessonsRenderFunc={doFetch} teacherID={teacherID} />
        </div>
    )
}

export default OneTime;
