import React from 'react';
import AttandanceSelectItem from './attandanceSelectItem.js';

const AttandanceSelect = ({ students, lesson }) => {

    return(
        students.map(student => 
            <AttandanceSelectItem key={student._id} student={student} lesson={lesson}/>
        )
    )
}

export default AttandanceSelect;