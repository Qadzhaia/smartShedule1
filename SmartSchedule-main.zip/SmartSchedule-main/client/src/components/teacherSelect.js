import React, { useEffect, useState } from 'react';
import useFetch from '../hooks/useFetch.js';

const TeacherSelect = ({defaultTeacherID="" ,changeHandler}) => {
    const [teachers, setTeachers] = useState('');
    const [{response}, doFetch] = useFetch('/user/teacher/all');

    useEffect(() =>{
        doFetch()
    },[doFetch])

    useEffect(()=>{
        if(!response){
            return
        }

        setTeachers(<>
            {response.map(el=>{
                    return <option key={el._id} value={el._id}>{el.userName}</option>
                })}
            </>)
    }, [response])

    return(
        <select className="teachers-select"  name="teacherId" onChange={changeHandler}>
            <option value="">Не выбран</option>
            {teachers}
        </select>
    )
}

export default TeacherSelect;