import React from "react";

const Loading = ({width=80, style}) => {

    return(
        <div style={style} className="loading-wrap">
            <div className="loading-component">
                <img alt="загрузка" width={width} src="./img/loading.gif" />
            </div>
        </div>
    )
}

export default Loading;