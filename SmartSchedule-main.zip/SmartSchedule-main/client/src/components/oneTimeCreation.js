import React, { useEffect, useState } from 'react';
import StudentSearch from './studentSearch';
import useFetch from '../hooks/useFetch.js';
import { useSelector } from 'react-redux';

const OneTimeCreation = ({teacherID, lessonsRenderFunc}) => {

    const currentUserState = useSelector(state => state.currentUser);
    const [{response}, doFetch] = useFetch('/onetime/create')

    const [formData, setFormData] = useState({
        date: new Date(),
        oneTimeType: "test",
        groupID: "",
        comment: "",
        hours: 0.75
    })


    const changeHandler = ({target}) => {
        setFormData({...formData, [target.name]: target.value})
    }

    const createClickHandler = () => {
        doFetch({
            method: 'post',
            data: {
               teacherID: teacherID,
               groupID: formData.oneTimeType === "test"? "": formData.groupID,
               lessonType: formData.oneTimeType,
               date: formData.date,
               comment: formData.comment,
               hours: formData.hours,
               teacherName: currentUserState.currentUser.userName
            }
        });
    }


    useEffect(()=>{
        if(!response) {
            return
        }

        lessonsRenderFunc()
    },[response, lessonsRenderFunc])

    return(
        <div className="onetime__creation-wrap">
            <div>
                <input autoComplete='off' onChange={changeHandler} type="date" name="date" />
            </div>
            <div>
                <select onChange={changeHandler} name="oneTimeType">
                    <option value="test">Пробное</option>
                    <option value="change">Замена</option>
                </select>
            </div>
            <div>
                {formData.oneTimeType !== "test" && <StudentSearch chandgeDataFunc={changeHandler}/>}
            </div>
            <div>
                <input autoComplete='off' placeholder="Комментарий/Имя студента на пробном" onChange={changeHandler} type="text" name="comment" />
            </div>
            <div>
                <input autoComplete='off' onChange={changeHandler} className="one-time__hours-input" defaultValue={0.75} step={0.25}  type="number" name="hours" />
            </div>
            <button onClick={createClickHandler} className="yc-button">Создать</button>
        </div>
    )
}

export default OneTimeCreation;