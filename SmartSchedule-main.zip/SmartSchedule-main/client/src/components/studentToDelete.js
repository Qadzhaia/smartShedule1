import React, { useEffect, useState } from "react";
import useFetch from '../hooks/useFetch.js';
import Loading from "./loading.js";
import StudentListItem from "./studentListItem.js";

const StudentToDelete = () => {
    const [studentList, setStudentList] = useState([])
    const [{response, isLoading}, doFetch] = useFetch('/student/');

    useEffect(()=>{
        doFetch()
    },[doFetch])

    const updateHandler = (studentID) => {
        setStudentList(g => g.filter(el=>el.props.studentId !== studentID))
    }

    useEffect(()=>{
        if(!response){
            return;
        }
        setStudentList(response.map(el=>{
            return <StudentListItem key={el._id} studentName={el.name} updateFunc={updateHandler} studentId={el._id}/>
        }))
    },[response])

    

    return(
        <div>
            <h3>Список студентов</h3>
            {isLoading && <Loading />}
            {studentList}
        </div>
    )
}

export default StudentToDelete;