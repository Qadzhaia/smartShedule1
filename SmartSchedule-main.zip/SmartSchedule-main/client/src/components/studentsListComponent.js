import React, { useEffect } from 'react';
import useFetch from '../hooks/useFetch.js';

const StudentsList = ({studnets, groupID, updateFunc, isManager}) => {
    const [{response}, doFetch] = useFetch('/student/deletefromgroup');

    const deleteClickHandler = (studentID, target) => {
        doFetch({
            method: "post",
            data: {
                groupID: groupID,
                studentID: studentID
            }
        })
        target.classList.add("d_none")
    }

    useEffect(()=>{
        if(!response) {
            return;
        }
        updateFunc()
    },[response, updateFunc])

    return(
        <ul className="student-list">
            {Array.isArray(studnets) && studnets.map(el=>{
                return <li className="student-list__item" key={el._id}>
                        {isManager && <button className="student-list__del-btn" onClick={({target})=>deleteClickHandler(el._id, target)}>x</button>} 
                        <span className="student-list__name">{el.name}</span>
                    </li>
            })}
        </ul>
    )
}

export default StudentsList;