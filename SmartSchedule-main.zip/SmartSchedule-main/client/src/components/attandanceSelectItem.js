import { useState } from "react";
import { useDispatch } from "react-redux";
import { SaveAttandance } from "../store/actions/lessons";

const AttandanceSelectItem = ({student, lesson}) => {
    const matchedObj = lesson.attendance.filter(el=> el.studentId === student._id)[0]
    const statusC = matchedObj === undefined ? "neural" :
        matchedObj.presence ? "yes" : "no";

    const [status, setStatus] = useState(statusC)
    
    const dispatch = useDispatch()

    const checkboxHandler = (target, studentId) => {
        const studentsAttandance = {
            studentId: studentId,
            presence: target.value === "yes" ? true : false
        }
        dispatch(SaveAttandance(lesson._id, studentsAttandance))
        setStatus(target.value)
    }

    return(
        <div>
            <select disabled={lesson.isChecked}
                    onChange={({target})=>checkboxHandler(target, student._id)} 
                    defaultValue={status} 
                    className={"lesson-attandance__box attandance__box--"+status}>
                <option value="neural"> </option>
                <option value="yes">+</option>
                <option value="no">×</option>
            </select>
        </div>
    )
}

export default AttandanceSelectItem;