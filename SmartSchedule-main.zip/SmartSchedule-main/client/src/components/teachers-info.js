import React, { useEffect, useState } from "react";
import useFetch from '../hooks/useFetch.js';
import Loading from "./loading.js";

const TeacherInfo = ({ teacher, curMonth = new Date().getMonth()+1, curYear = new Date().getFullYear() }) => {
    const [{response, isLoading}, doFetch] = useFetch(`/lesson/count-lessons/${teacher.userID}/${curMonth}/${curYear}`);
    const [hours, setHours] = useState("");

    useEffect(()=>{
        doFetch()
    },[doFetch])

    useEffect(()=>{
        if(!response) {
            return
        }

        setHours(response.message);
    },[response])

    return (
        <div className="teacher-info">
            <div className="teacher-info__item teacher-info__hours" onClick={doFetch}>
                {isLoading && <Loading style={{marginRight: "43px",
                marginBottom: "25px"}} width={50}/>}
                {!isLoading &&
                <>
                    <p className="teacher-info__description">проведено</p>
                    <p className="teacher-info__value">{hours} часов</p>
                </>
                }
            </div>
            <div className="teacher-info__item teacher-info__cash">
                <p className="teacher-info__description">заработано</p>
                <p className="teacher-info__value">{hours*400} руб</p>
            </div>
        </div>
    )
}

export default TeacherInfo;