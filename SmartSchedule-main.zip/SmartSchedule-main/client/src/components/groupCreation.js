import React, { useEffect, useState } from 'react';
import useFetch from '../hooks/useFetch.js'
import TeacherSelect from './teacherSelect.js';

const GroupCreation = () => {
    const [groupDate, setGroupData] = useState({
        name: "", teacherId: ""
    });

    const [{response}, doFetch] = useFetch('/group/create');

    const [message, setMessage] = useState("")


    const changeHandler = ({target}) => {
        setGroupData({...groupDate, [target.name]: target.value});
    }

    const createHandler = () => {
        doFetch({
            method: 'post',
            data: groupDate
        })

        document.getElementById("groupName").value = ""
    }

    useEffect(()=>{
        if(!response){
            return
        }
        
        setMessage(
            <>
                <div>Группа <b>{response.name}</b> создана</div>
                <div>ID группы: <b>{response._id}</b></div>
            </>
        )
    },[response])

    return(
        <div className="group-creation">
            <div>
                <h2>Группы</h2>
                <div className="creating-page__input-wrap"> 
                    <input autoComplete='off' type="text" placeholder="Название группы" id="groupName" name="name" onChange={changeHandler} />
                </div>
                <div className="creating-page__input-wrap" >
                    <TeacherSelect changeHandler={changeHandler}/>
                </div>
                <div className="creating-page__input-wrap">
                    <button className="yc_button" onClick={createHandler}>Создать</button>
                </div>
            </div>
            <div className="group-creation__log">
                <h3>Логи</h3>
                <div>
                    {message}
                </div>
            </div>
        </div>
    )
}

export default GroupCreation