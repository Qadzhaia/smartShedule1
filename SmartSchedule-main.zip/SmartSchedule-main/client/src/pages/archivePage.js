import React from "react";
import GroupArchive from "../components/groupArchive";
import StudentToDelete from "../components/studentToDelete";

const ArchivePage = () => {

    return(
        <div className="container">
            <h1>Страница управления архивом</h1>
            <div className="archive-page__wrap">
                <GroupArchive />
                <StudentToDelete />
            </div>
        </div>
    )
}

export default ArchivePage;