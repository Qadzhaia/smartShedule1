import React, { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import GroupList from '../components/groupList.js';
import OneTime from '../components/oneTime.js';
import { FetchLessons } from '../store/actions/lessons.js';

const LessonsPage = () => {
    const currentUserState = useSelector(state => state.currentUser);
    const dispatch = useDispatch();
    const lessonsState = useSelector(state =>  state.lessons);
    
    const mounthChange = useCallback(({target}) => {
        dispatch({type: "SET_MONTH", payload: target.value})
    },[dispatch])

    useEffect(()=>{
        dispatch(FetchLessons(lessonsState.month))
    },[lessonsState.month, dispatch])
    
    return(
        <div className="container lessons-page__wrap">
            <h1>Ведомость занятий</h1>
            <div>
                <h4>Месяц</h4>
                <select onChange={mounthChange} defaultValue={lessonsState.month}>
                    <option value="1">Январь</option>
                    <option value="2">Февраль</option>
                    <option value="3">Март</option>
                    <option value="4">Апрель</option>
                    <option value="5">Май</option>
                    <option value="6">Июнь</option>
                    <option value="7">Июль</option>
                    <option value="8">Август</option>
                    <option value="9">Сентябрь</option>
                    <option value="10">Октябрь</option>
                    <option value="11">Ноябрь</option>
                    <option value="12">Декабрь</option>
                </select>
            </div>
            <OneTime currentMounth={lessonsState.month} teacherID={currentUserState.currentUser !== null ? currentUserState.currentUser.userID: ""}/>
            {/* {isLoading && <Loading />} */}
            <GroupList lessonsArr={lessonsState.lessonsList}/>
        </div>
    )
}

export default LessonsPage;
