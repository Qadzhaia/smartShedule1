import {useState, useCallback} from 'react'
const LocalStorageHook = (key, initialValue = '') => {
  const [value, setValue] = useState(() => {
    try {
      return localStorage.getItem(key) ? JSON.parse(localStorage.getItem(key)) : initialValue
    } catch (error) {
      return initialValue
    }
    
  })

  const setNewValue = useCallback((value)=>{
    setValue(value)
    localStorage.setItem(key, JSON.stringify(value));
  },[setValue, key])

  return [value, setNewValue]
}

export default LocalStorageHook
